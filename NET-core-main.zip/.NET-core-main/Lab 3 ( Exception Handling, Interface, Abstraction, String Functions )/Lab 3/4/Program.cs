﻿//Write a program to create interface Calculate. In this interface we have two
//member functions Addition() and Subtraction(). Implements this interface
//in another class named Result.

using _4;

var result = new Result();
Console.WriteLine(result.Addition(10, 5));
Console.WriteLine(result.Subtraction(10, 5));