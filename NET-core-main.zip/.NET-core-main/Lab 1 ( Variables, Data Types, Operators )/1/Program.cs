﻿// See https://aka.ms/new-console-template for more information
//Write a program to print your name, address, contact number & city.
Console.WriteLine("My Name is Jay");
Console.WriteLine("Address: 123 Main Street");
Console.WriteLine("Contact Number: 98796*****");
Console.WriteLine("City: Morbi");


