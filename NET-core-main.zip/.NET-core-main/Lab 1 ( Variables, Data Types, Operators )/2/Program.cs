﻿// See https://aka.ms/new-console-template for more information
//Write a program to get two numbers from user and print those two numbers.
Console.Write("Enter the first number: ");
string input1 = Console.ReadLine();
Console.Write("Enter the second number: ");
string input2 = Console.ReadLine();

Console.WriteLine("You entered:");
Console.WriteLine("First number: " + input1);
Console.WriteLine("Second number: " + input2);
